//Aluno

void matriculaCurso();

void matriculaDisciplina();

void cancelarDisciplina();

void historicoCompleto();

void historicoSemestre();