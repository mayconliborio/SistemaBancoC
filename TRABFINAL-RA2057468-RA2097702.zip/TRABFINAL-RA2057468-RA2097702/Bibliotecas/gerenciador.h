//Gerenciador

void cadastrarDisciplina();

void cadastrarTurma();

void cadastrarProfessor();

void excluirDisciplina();

void excluirTurma();

void excluirProfessor();