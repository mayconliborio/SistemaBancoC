//Professor

void inserirNotas();

void alterarNotas();

void inserirFrequencia();

void alterarFrequencia();

void desempenhoAlunoSemestre();

void desempenhoTurmaSemestre();

void alunosAprovadosPorDisciplina();

void alunosReprovadosPorDisciplina();

void relatorioCompleto();